module.exports = {
    "development": {
        "host": "",
        "port": "",
        "url":""
    },
    "test": {
        "host": "",
        "port": "",
        "url":""
    },
    "production": {
        "host": "",
        "port": "",
        "url":""
    }
}